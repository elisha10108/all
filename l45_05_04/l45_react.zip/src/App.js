import logo from './logo.svg';
import './App.css';
import AppCounter from './counter_comps/appCounter';
import React from 'react';
import AppShop from './shop_comps/appShop';

function App() {
  return (
    <React.Fragment>
      <AppShop />
      <hr />
      <AppCounter/>
    </React.Fragment>
  );
}

export default App;

// 10:50