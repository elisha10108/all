import React, { useState } from 'react';
import Counter from './counter';
import CounterShow from './counterShow';
import { AppContext } from "../context/counterContext";


function AppCounter(props) {
  let [counter,setCounter] = useState(0);
  let [user , setUser] = useState("koko")
  return (
    // יש לעטוף את הקומפנטנטה 
    // APPCONTEXT.PROVIDER
    // בכל הקומפנינטות שישתמשו בסטור הגלובלי
    // VALUE -> מאפיין שמעביר את כל מה שבתוכו לכל הקומפננטות
    // שעשות אימפורט
    <AppContext.Provider value={{
      counter,setCounter , 
      user,setUser
      }}>
      <div className="container">
        <div className="row">
          <Counter />
          <CounterShow />
        </div>
      </div>
    </AppContext.Provider>
  )
}

export default AppCounter