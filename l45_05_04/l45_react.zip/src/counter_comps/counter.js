import React from 'react';
import CounterControl from './counterControl';

function Counter(props){
  return(
    <div style={{minHeight:"300px"}} className="col-lg-6 border p-2">
      <h2>Click on the button inside the comp</h2>
      <CounterControl />
    </div> 
  )
}

export default Counter