import React, {useContext} from 'react';
import {AppContext} from "../context/counterContext";

function CounterControl(props){
  // כדי לאסוף את המידע מהווליו באפ יש להשתמש ב
  // יוז קונטיקסט על הקונטקסט/הסטור שנרצה לשלוף ממנו מידע
  let {counter,setCounter} = useContext(AppContext);

  return(
    <div>
      <h2>Info from context: </h2>
      <button onClick={() => {
        setCounter(counter+1);
      }} className="btn btn-outline-success">Add 1 to counter</button>
    </div> 
  )
}

export default CounterControl