import React, {useContext} from 'react';
import {AppContext} from "../context/counterContext";

function CounterShow(props){
  let {counter} = useContext(AppContext);
  return(
    <div  style={{minHeight:"200px"}} className="bg-warning col-lg-6 border p-2">
      CounterShow work
      <h3>Counter: {counter}</h3>
    </div> 
  )
}

export default CounterShow