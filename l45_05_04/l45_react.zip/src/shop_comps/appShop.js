import React, { useEffect, useState } from 'react';
import ShopCart from './shopCart';
import ShopList from './shopList';
import {ShopContext} from "../context/shopContext";

function AppShop(props){
  let [cart_ar,setCartAr] = useState([]);
// שומר בלוקאל וגם מעובר בפרובידיר בווליו של הקונטקסט
  const saveToLocal = (_ar) => {
    localStorage.setItem("cart",JSON.stringify(_ar));

  }
// בדיקה אם לוקאל שקשור לעגלת קניות
  useEffect(() => {
    // 
    if(localStorage["cart"]){
      setCartAr(JSON.parse(localStorage["cart"]))
    }
  },[])

  return(
    <ShopContext.Provider value={{cart_ar,setCartAr,saveToLocal}}>
    <div className="container">
      AppShop work
      <div className="row">
      <ShopList />
      <ShopCart />
      </div>
    </div> 
    </ShopContext.Provider>
  )
}

export default AppShop