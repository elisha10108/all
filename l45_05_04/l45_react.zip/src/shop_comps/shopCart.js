import React,{useContext} from 'react';
import {ShopContext} from "../context/shopContext";

function ShopCart(props){
  let {cart_ar,setCartAr,saveToLocal} = useContext(ShopContext);

  const delFromCart = (_id) => {
    let temp_ar = cart_ar.filter(item => {
      return item.id != _id;
    })
    setCartAr(temp_ar)
    // שומר בלוקאל
    saveToLocal(temp_ar)
  }

  return(
    <div className="col-lg-3 border p-2 bg-light"> 
      {cart_ar.map(item => {
        return(
          <div class="border p-2">
            <button onClick={() => {
              delFromCart(item.id)
            }} className="btn btn-danger float-end">X</button>
            <h2>{item.name}</h2>
          </div>
        )
      })}
    </div> 
  )
}

export default ShopCart