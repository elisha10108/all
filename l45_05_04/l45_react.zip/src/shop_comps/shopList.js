import axios from 'axios';
import React, { useEffect, useState } from 'react';
import ShopItem from './shopItem';

function ShopList(props){

  let [prods_ar,setProdsAr] = useState([]);

  useEffect(() => {
    doApi();
  },[])

  const doApi = async() => {
    let url = "http://fs1.co.il/bus/shop.php"
    try{
      let resp = await axios(url);
      console.log(resp.data)
      setProdsAr(resp.data);
    }
    catch(err){
      console.log(err);
      alert("There is problem, try again later!")
    }
  }

  return(
    <div className="col-lg-9 border p-2">
      <h2>List of prods:</h2>
      <div className="row">
        {prods_ar.map(item => {
          return(
            <ShopItem key={item.id} item={item} />
          )
        })}
      </div>
    </div> 
  )
}

export default ShopList