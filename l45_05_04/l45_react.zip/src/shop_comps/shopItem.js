import React,{useContext} from 'react';
import {ShopContext} from "../context/shopContext";

function ShopItem(props){
  let {cart_ar,setCartAr,saveToLocal} = useContext(ShopContext);

  let item = props.item;
  
  const addToCart = () => {
    setCartAr([...cart_ar,item])
    saveToLocal([...cart_ar,item]);
  }

  return(
    <div className="col-lg-6 border p-2">
      <h2>{item.name}</h2>
      <button onClick={addToCart} className="btn btn-info">Add to cart</button>
    </div> 
  )
}

export default ShopItem