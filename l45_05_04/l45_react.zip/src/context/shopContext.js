import {createContext} from 'react';
 // מגדיר סטור גלובלי שכל הקומפננטות יוכלו לעשות
 // לו אימפורט
export const ShopContext = createContext(null);

// 13:10