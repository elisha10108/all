import {createContext} from 'react';
 // מגדיר סטור גלובלי שכל הקומפננטות יוכלו לעשות
 // לו אימפורט
export const AppContext = createContext(null);