import logo from './logo.svg';
import './App.css';
import ScrollPage from './scroll_comps/scrollPage';
import ScrollPageGood from './scroll_comps/scrollPageGood';
import ScrollVod from './scroll_comps/scrollVod';
import { BrowserRouter as Router, Switch, Route ,Link } from 'react-router-dom';
import AppPayPal from './paypal_comps/appPayPal';

function App() {
  return (
    <Router className="App">
      <h1>React work!!!! 222</h1>
      <nav className="container">
        <Link to="/">Home</Link>  | 
        <Link to="/testScroll">Test scroll</Link> |
        <Link to="/paypal">pay pal page</Link>
      </nav>
      <Switch>
        <Route exact path="/" component={ScrollVod} />
        <Route exact path="/testScroll" component={ScrollPage} />
        <Route exact path="/paypal" component={AppPayPal} />
      </Switch>
      {/* <ScrollVod /> */}
      {/* <ScrollPage /> */}
      {/* <ScrollPageGood /> */}
    </Router>
  );
}
// 10:50
export default App;
