import React, { useState } from 'react';
import PayPalBtn from './paypalBtn';


function AppPayPal(props){
  let [total,setTotal] = useState(200);

  return(
    <div className="container">
      <PayPalBtn />
      AppPayPal work
    </div> 
  )
}

export default AppPayPal