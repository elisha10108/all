import React, { useEffect, useState } from 'react';
import { useScrollBottom } from "../hooks/useScrollBottom"

function ScrollVod(props) {
  // משתמש בהוק שלנו שבוק אם הגענו לתחתית
  let [bottomPage] = useScrollBottom();
  let [ar, setAr] = useState([]);
  // משתמש בשביל היו אר אל של האיי פי איי
  let [page, setPage] = useState(1);
  // אם להציג את הגיף של הטעינה בנוסף דואג 
  // שלא יהיה טעינה נוספת בגלילה
  let [showLoading, setShowLoading] = useState(false);


  useEffect(() => {
    // יפעיל את העצמו בהתחלה וכל פעם שהפייג' משתנה
    // מהיוז אפקט השני שבודק את הגלילה
    doApi();
  }, [page])

  useEffect(() => {
    // בודק שהגענו לתחתית וגם שהוא לא במצב טעינה כרגע
    if (bottomPage && !showLoading) {
      setPage(page + 1)
    }
  }, [bottomPage])

  const doApi = async () => {
    setShowLoading(true);
    let url = "http://www.omdbapi.com/?s=yellow&apikey=5a292f28&page=" + page
    let resp = await fetch(url);
    let data = await resp.json();
    // כדי שיוסיף שירים
    setAr([...ar, ...data.Search]);
    setShowLoading(false)
  }

  return (
    <div className="container">
      <h1>List of Movies:</h1>
      <div className="row justify-content-center text-center">
        {ar.map(item => {
          return (
            <div className="col-lg-7 border">
              <img src={item.Poster} className="img-thumbnail w-50" />
              <h4>{item.Title}</h4>
            </div>
          )
        })}
        {showLoading &&
          <div>
            <img src="loading.gif" className="w-25" />
          </div>}
      </div>
    </div>
  )
}

export default ScrollVod