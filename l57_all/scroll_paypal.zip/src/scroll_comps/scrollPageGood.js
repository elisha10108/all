import React, { useEffect, useState } from 'react';
import {useScrollBottom} from "../hooks/useScrollBottom"

function ScrollPageGood(props){
  let [bottomPage] = useScrollBottom();
  let [showMore , setShowMore] = useState(false)



  useEffect(() => {
    if(bottomPage){
      setShowMore(true);
      
    }
  },[bottomPage])


  return(
    <div className="container">
      <div className="bg-warning" style={{minHeight:"1200px"}}>
        ssasadsad
      </div>
      ScrollPage work
      {showMore && <div className="bg-danger" style={{minHeight:"1200px"}}>
        more div
      </div>}
    </div> 
  )
}

export default ScrollPageGood