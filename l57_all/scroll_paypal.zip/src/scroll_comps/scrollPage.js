import React, { useEffect } from 'react';

function ScrollPage(props){

  useEffect(() => {
    window.addEventListener("scroll",onScroll)
    return () => {
      // כדי שאם נעבור לראוט אחר ונחזור
      // והקומפנינטה תטען , לא יציג שוב 
      window.removeEventListener("scroll",onScroll)
    }
  },[])

  const onScroll = (ev) => {
    console.log("eee",ev);
    //window.innerHeight -> הגובה של החלון מה שהמתשמש צופה
    // document.documentElement.scrollTop -> נקודת הוואי של גלילת החלון , שאנחנו בהתחלה מתחיל מ0 0
    // document.documentElement.offsetHeight -> הגובה של כל המסמך מלמעלה למטה כולל הגלילה
    console.log(window.innerHeight ,  document.documentElement.scrollTop , document.documentElement.offsetHeight)
    if(window.innerHeight +  document.documentElement.scrollTop >= document.documentElement.offsetHeight){
      alert("end of screen")
    }
  }

  return(
    <div className="container">
      <div className="bg-info" style={{minHeight:"1200px"}}>
        ssasadsad
      </div>
      ScrollPage work
    </div> 
  )
}

export default ScrollPage