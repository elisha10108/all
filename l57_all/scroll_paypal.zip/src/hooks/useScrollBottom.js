import React,{ useEffect, useState } from "react";

//TODO: transfer params of Y offset for tell if end of screen
export const useScrollBottom = () => {
  let [touchEnd,setTouchEnd] = useState(false);

  useEffect(() => {
    window.addEventListener("scroll",onScroll)
    // רטרן פועל רגע לפני שקומפיננטה או הוא נמחקים מהזכרון
    return () => {
      // כדי שאם נעבור לראוט אחר ונחזור
      // והקומפנינטה תטען , לא יפעיל שוב 
      console.log("remove event")
      window.removeEventListener("scroll",onScroll)
    }
  },[])

  const onScroll = () => {
   
     //window.innerHeight -> הגובה של החלון מה שהמתשמש צופה
    // document.documentElement.scrollTop -> נקודת הוואי של גלילת החלון , שאנחנו בהתחלה מתחיל מ0 
    // document.documentElement.offsetHeight -> הגובה של כל המסמך מלמעלה למטה כולל הגלילה
    if(window.innerHeight +  document.documentElement.scrollTop >= document.documentElement.offsetHeight){
      console.log("end")
      setTouchEnd(true);
    }
    else{
      setTouchEnd(false)
    }
  }

  // כשבודקים בקומפונינטה ביוז אפקט את המשתנה 
  // צריך להכניס אותו במערך שיפעל ברגע שהוא משתנה
  return [touchEnd];
}



// created by monkeys.co.il best site ever!!!!