import React from 'react';
import { BrowserRouter as Router, Switch, Route  } from 'react-router-dom';
import AppAdmin from './admin/appAdmin';
import HeaderAdmin from './admin/headerAdmin';
import Login from './admin/login';

function AppMarket(props){
  return(
    <Router>
      <Switch>
        {/* show the HeaderAdmin in admin section only */}
        <Route path={"/admin"} component={HeaderAdmin} />
      </Switch>
      {/* switch of the content */}
        <Switch>
          <Route exact path={`/`} component={Login} />
          <Route path={`/admin`} component={AppAdmin} />
    
        </Switch>  
    </Router>
  )
}

export default AppMarket

