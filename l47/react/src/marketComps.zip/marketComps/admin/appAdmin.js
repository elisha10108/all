import React from 'react';
import { BrowserRouter as Router, Switch, Route  } from 'react-router-dom';
import Login from './login';
import ListProdAdmin from "./listProdAdmin";

function AppAdmin(props){
  return(
    <div className="container-fluid">
      <div className="row">
        <div className="col-2 bg-dark" style={{minHeight:"100vh"}}></div>
        <div className="col-9">
          <Switch>
            <Route exact path={`/admin/login`} component={Login} />
            <Route exact path={`/admin/list`} component={ListProdAdmin} />
          </Switch>
        </div>
      </div>
      
    </div> 
  )
}

export default AppAdmin;