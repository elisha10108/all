import React from 'react';
import {Link} from "react-router-dom";

function HeaderAdmin(props) {
  return (
    <div className="container-fluid bg-dark text-light">
      <div className="container">
        <div className="row justify-content-between align-items-center">
          <div className="col-lg-3">
            <h2>Admin market</h2>
          </div>
          <div className="col-lg-6 text-end">
            <Link to="/admin/login" className="text-white">Log out</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default HeaderAdmin;