import React from 'react';

function ListProdAdmin(props){
  return(
    <div>
      list prod
    </div> 
  )
}

export default ListProdAdmin;