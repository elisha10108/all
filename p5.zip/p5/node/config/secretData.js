// כל מה שסודי כמו סיסמא , יוזר יהיה כאן
exports.config = {
  jwtSecret:"elisha",
  mongoPass:"elisha",
  mongoUser:"elisha"
}