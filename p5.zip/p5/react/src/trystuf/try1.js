import axios from 'axios';
import React, { useEffect, useState } from 'react';


function TrySometing(props){

let [arr,setarr]= useState([]);
let [ar,setar]=useState("")
useEffect(() => {

doApi();
}, [])
const doApi= async()=>
{ 
  let url ='https://www.balldontlie.io/api/v1/players';
  let resp = await axios(url);

  console.log(resp.data.data);
  setarr(resp.data.data )


}


const on = (e)=>{
console.log(e);
setar("position:"+e.position)
}

    
    return(
        <div>

{arr.map((item,i)=> {
return(
<div 


key={i}>
<h1 
> {i+1}  {item.first_name}  {item.last_name}</h1>
<a onClick={()=>{
        on(item)}
    }href="#">for more info</a>
     {ar ? <div>{ar}</div>:
""
     }
<hr/>
</div>
)
})}

        </div> 
    )
}

export default TrySometing