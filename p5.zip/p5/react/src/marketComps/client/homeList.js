import React, { useEffect,  useState } from 'react';
import { doApiGet, URL_API } from '../../services/apiSer';
import HomeCatList from './homeCatList';


function Homelist(props){
let [catId,setcatId]=useState([]);
let [refresh,setrefresh]=useState(0);
  useEffect(() =>{
doApi();
  },[refresh])


const doApi = async()=>{
  let url = URL_API +'/categories/singleCat'
 let data = await doApiGet(url);

setcatId(data)
setrefresh(1)
// console.log("data",catId);
}

  return(
    
      <div className="container-fluid">
        <div className="container">
          {catId.map((item,i)=>{
            return(

              <HomeCatList key={i} catId={item.s_id} />

            )
          })

          }
        
        </div>
      </div>
     
  )
}

export default Homelist