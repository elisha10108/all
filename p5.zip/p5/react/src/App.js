
// import './App.css';
// import TrySometing from './trystuf/try1';
import AppMarket from './marketComps/appMarket';



function App() {


  return (
    <div className="App">
      
      <AppMarket />
 {/* <TrySometing/> */}

     
    </div>
  );
}

export default App;
