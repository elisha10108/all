import React from 'react';
import Header from './header';

function Home(props){
  return(
    <React.Fragment>
      <Header />
    </React.Fragment> 
  )
}

export default Home