import React from 'react';
import {useSelector, useDispatch} from "react-redux"

function CounterControl(props){
  let counter = useSelector(myStore => myStore.counter);
  let dispatch = useDispatch();

  return(
    <div>
      <button onClick={() => {
        dispatch({type:"add1Counter"})
      }}>Add 1 counter</button>
      <button onClick={() => {
        dispatch({type:"addCustomCounter", number:3})
      }}>Add 3 counter</button>
      <button onClick={() => {
        dispatch({type:"addCustomCounter", number:10})
      }}>Add 10 counter</button>
    </div> 
  )
}

export default CounterControl