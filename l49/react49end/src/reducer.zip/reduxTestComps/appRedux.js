import React, { useState } from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import TestReducer from "../reducer/testReducer";
import CounterShow from './counterShow';
import CounterControl from './counterControl';

//store -> מגדיר את אחסון הגלובלי שכל הקומפנינטות ישתמשו בו
//TestReducer -> אחראי לספק את הסטייט הנוכחי הגלובלי ולעדכן אותו



const myStore = createStore(TestReducer);

function AppRedux(props) {
  return (
    <Provider store={myStore}>
      <div className="container">
        <CounterShow  />
        <CounterControl  />
      </div>
    </Provider>
  )
}

export default AppRedux