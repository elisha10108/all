import React from 'react';
import { BrowserRouter as Router, Switch, Route  } from 'react-router-dom';
import ListProdAdmin from './admin/listProdAdmin';
import Login from './admin/login';

function AppMarket(props){
  return(
    <Router>
      <div className="container">
        <Switch>
          <Route exact path={`/`} component={Login} />
          <Route exact path={`/admin/login`} component={Login} />
          <Route exact path={`/admin/list`} component={ListProdAdmin} />
        </Switch>  
      </div> 

    </Router>
  )
}

export default AppMarket