import React from 'react';

function ListProdAdmin(props){
  return(
    <div>ListProdAdmin work</div> 
  )
}

export default ListProdAdmin;