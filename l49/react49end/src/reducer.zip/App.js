import logo from './logo.svg';
import './App.css';
import AppMarket from './marketComps/appMarket';
import AppRedux from './reduxTestComps/appRedux';

function App() {
  return (
    <div className="App">
      <AppRedux />
    </div>
  );
}
// 10:50
export default App;
