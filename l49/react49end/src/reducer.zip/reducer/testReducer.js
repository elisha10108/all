// הסטייט הגלולבי ההתחלתי שהאפליקציה מקבלת שהיא נטענת
const initState = {
  counter: 77,
  user:"moshe"
}

// single source of truth -> מקור אחד שמאפשר שינוי של הסטייט
const TestReducer = (state = initState , action) => {
  if(action.type == "add1Counter"){
    // ...state -> כדי שלמשל המאפיין יוזר לא ימחק מהסטייט
    return {...state, counter:state.counter+1};
  }
  else if(action.type == "addCustomCounter"){
    return {...state, counter:state.counter+action.number}
  }
  return state;
}

export default TestReducer;
