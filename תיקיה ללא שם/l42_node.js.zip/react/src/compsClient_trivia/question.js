import React, { useEffect, useState } from 'react';
import {shuffle} from "lodash"
import { doApiMethod, URL_API } from '../services/apiSer';
import { useToasts } from "react-toast-notifications";
function QuestionItem(props){

  // מערך שיכיל את ה4 התשובות
  let [a_ar,setAr] = useState([]);
  // משתנה שמכיל את התשובה הנכונה כדי לעשות בדיקה
  let [correctAnswer,setCorrectAnswer] = useState("");
  let { addToast } = useToasts();

  useEffect(() => {
    let temp_ar = shuffle([props.qusetion.a1,props.qusetion.a2,props.qusetion.a3,props.qusetion.a4])
    setAr(temp_ar);
    setCorrectAnswer(props.qusetion.a1);
  },[props.qusetion])

  const checkAnswer = (_val) => {
    if(correctAnswer == _val){
    //  alert("success");
    // לעדכן את הרשומה של המשתמש שהוא ענה על השאלה 
    addToast("תשובה מעולה",
    {
      appearance: 'success',
      autoDismiss: true
    })
      props.apiScore(10);
    }
    else{
   //   alert("worng, you stupid!!!");
   addToast("טעות , נסה שוב !!!",
   {
     appearance: 'error',
     autoDismiss: true
   })
      props.apiScore(-20);
    }
    // עובר לשאלה הבאה
    props.doApi();
  }



  return(
    <React.Fragment>
      <h1 className="mt-5 display-3"> {props.qusetion.q}</h1>
      <div className="mt-5">
        {a_ar.map((item,i) => {
          return(
          <button onClick={() => {checkAnswer(item)}} className="col-lg-3 btn btn-dark d-block mb-3 mx-auto"
          key={i} >{item}</button>
          )
        })}
      </div>
    </React.Fragment>
  )
}

export default QuestionItem