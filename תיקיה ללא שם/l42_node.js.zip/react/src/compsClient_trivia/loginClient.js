import React from 'react';
import { useToasts } from "react-toast-notifications";
import { useForm } from "react-hook-form";
import { useHistory } from 'react-router';
import { doApiMethod, URL_API } from '../services/apiSer';
import { Link } from 'react-router-dom';

function LoginClient(props) {
  const { register, handleSubmit, errors } = useForm();
  let emailRef = register({ required: true, pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i });
  let passRef = register({ required: true, minLength: 3 })
  let history = useHistory()
  let { addToast } = useToasts();

  const onFormSub = (dataBody) => {
    //dataBody -> מכיל אובייקט עם המאפיינים לפי השמות של האינפוטים והסלקטים
    console.log(dataBody);
    doApi(dataBody)
  }

  const doApi = async (dataBody) => {
    let url = URL_API + "/users/login";
    // dataBody > אובייקט שמכיל את האימייל והסיסמא מהטופס
    let data = await doApiMethod(url, "POST", dataBody);
    console.log(data);
    // login success
    if (data.token) {
      // פונקציה שקוראת להודעת טוסט , צבע ירוק ושיעלם
      addToast("you logged in",
        {
          appearance: 'success',
          autoDismiss: true
        })
      localStorage.setItem("tok", data.token);
      history.push("/game");
    }
    else {
      addToast("Try again , user or password worng",
        {
          appearance: 'error',
          autoDismiss: true
        }
      )
    }
  }

  return (
    <div className="screen">
      <div className="container bg-light">
        <h1 className="mt-5 display-1">כניסה</h1>
        <form onSubmit={handleSubmit(onFormSub)} className="col-lg-6 mx-auto p-2 shadow mt-3">
          <div className="mb-3">
            <label htmlFor="email" className="form-label">כתובת אימייל</label>
            <input ref={emailRef} name="email" type="text" className="form-control" id="email" />
            {/* האירור לפי השם של האינפוט מייצר לעצמו מאפיין אם יש שם טעות */}
            {errors.email && <span className="text-danger">Please enter valid Email</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="pass" className="form-label">סיסמא:</label>
            <input ref={passRef} name="pass" type="text" className="form-control" id="pass" />
            {errors.pass && <span className="text-danger">Please enter valid Password min 3 charts</span>}
          </div>

          <button type="submit" className="btn btn-primary">כניסה</button>
          <Link to={"/"} className="btn btn-danger">יציאה</Link>


        </form>
      </div>
    </div>
  )
}

export default LoginClient