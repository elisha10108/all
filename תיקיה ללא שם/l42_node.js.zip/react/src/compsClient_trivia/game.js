import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import { doApiMethod, URL_API } from '../services/apiSer';
import QuestionItem from './question';

function Game(props){
  // המידע של השאלה
  let [q,setQ] = useState({});
  let [score,setScore] = useState(0);

  useEffect(()=> {
    doApi()
    apiScore(0);
  },[])

  const doApi = async() => {
    let Url = URL_API+"/trivia/randomQ";
    let data = await doApiMethod(Url,"GET");
    console.log(data);
    setQ(data);
  }

  const apiScore = async(_scoreVal) => {
    let url = URL_API+"/users/addScore"
    let data = await doApiMethod(url,"PUT",{score:_scoreVal})
    // מכיוון שאם מספר שווה ל0 בבדיקה שלו
    // הוא פולס ולכן גם נבדוק או שווה 0
    if(data.newScore || data.newScore == 0){
      setScore(data.newScore);
    }
  }


  let history = useHistory()
  return(
    <div className="screen">
    <div className="container bg-light">
      <QuestionItem apiScore={apiScore} doApi={doApi} qusetion={q} />
      <h2>ניקוד: {score}</h2>
      <button className="btn btn-danger" onClick={() => {
        localStorage.removeItem("tok");
        history.push("/");
      }}>צא מהמשחק</button>
    </div>
  </div> 
  )
}

export default Game