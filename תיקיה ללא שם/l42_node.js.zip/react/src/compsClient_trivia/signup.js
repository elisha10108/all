import React from 'react';
import { useToasts } from "react-toast-notifications";
import { useForm } from "react-hook-form";
import { useHistory } from 'react-router';
import { doApiMethod, URL_API } from '../services/apiSer';
import { Link } from 'react-router-dom';

function SignUp(props) {
  const { register, handleSubmit, errors } = useForm();
  let nameRef = register({ required: true, minLength:2,maxLength:100 });
  let emailRef = register({ required: true, pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i });
  let passRef = register({ required: true, minLength: 3 })
  // https://codesandbox.io/s/react-hook-form-password-match-check-standard-validation-eo6en?from-embed

  let history = useHistory()
  let { addToast } = useToasts();

  const onFormSub = (dataBody) => {
    //dataBody -> מכיל אובייקט עם המאפיינים לפי השמות של האינפוטים והסלקטים
    console.log(dataBody);
    doApi(dataBody)
  }

  const doApi = async (dataBody) => {
    let url = URL_API + "/users/";
    // dataBody > אובייקט שמכיל את האימייל והסיסמא מהטופס
    let data = await doApiMethod(url, "POST", dataBody);
    console.log(data);
    // login success
    if (data._id) {
      // פונקציה שקוראת להודעת טוסט , צבע ירוק ושיעלם
      addToast("הצלחת להרשם, גאון",
        {
          appearance: 'success',
          autoDismiss: true
        })
      history.push("/loginClient");
    }
    else {
      addToast("יש בעיה כרגע בשרת, תחזור בעוד שעה לפחות או המשתמש קיים",
        {
          appearance: 'error',
          autoDismiss: true
        }
      )
    }
  }

  return (
    <div className="screen">
      <div className="container bg-light">
        <h1 className="mt-5 display-1">הרשמה לטריוויה</h1>
        <form onSubmit={handleSubmit(onFormSub)} className="col-lg-6 mx-auto p-2 shadow mt-3">
        <div className="mb-3">
            <label htmlFor="name" className="form-label">שם:</label>
            <input ref={nameRef} name="name" type="text" className="form-control" id="name" />
            {/* האירור לפי השם של האינפוט מייצר לעצמו מאפיין אם יש שם טעות */}
            {errors.name && <span className="text-danger">Please enter valid name</span>}
          </div>
          
          <div className="mb-3">
            <label htmlFor="email" className="form-label">כתובת אימייל</label>
            <input ref={emailRef} name="email" type="text" className="form-control" id="email" />
            {/* האירור לפי השם של האינפוט מייצר לעצמו מאפיין אם יש שם טעות */}
            {errors.email && <span className="text-danger">Please enter valid Email</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="pass" className="form-label">סיסמא:</label>
            <input ref={passRef} name="pass" type="text" className="form-control" id="pass" />
            {errors.pass && <span className="text-danger">Please enter valid Password min 3 charts</span>}
          </div>
          {/* <div className="mb-3">
            <label htmlFor="pass2" className="form-label">סיסמא:</label>
            <input ref={pass2Ref} name="pass2" type="text" className="form-control" id="pass2" />
            {errors.pass2 && <span className="text-danger">סיסמא לא מתאימה לסיסמא 1</span>}
          </div> */}

          <button type="submit" className="btn btn-primary">הרשמה</button>
          <Link to={"/"} className="btn btn-danger">יציאה</Link>


        </form>
      </div>
    </div>
  )
}

export default SignUp