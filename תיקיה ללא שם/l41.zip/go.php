<?php 
// מחבר את הקובץ פייג' 2
// גם אם לא מוצא את הקובץ רק יציג שגיאה וימשיך
include "./page2.php";

// דומה לאינקלוד אבל אם לא מוצא את הקובץ מחזיר שגיאה פטאלית
// ועוצר את הקוד
// require "./page2.php";

// echo -> להדפיס
// דומה ל innerHTML
  echo "first line <br>";
  echo "HEllo from PHP 9999";

?>