<?php
  echo "this is page 2 <br>";
?>