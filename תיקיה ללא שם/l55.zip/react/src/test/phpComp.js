import React from 'react';

function PhpComp(props){
  return(
    <div>PhpComp work</div> 
  )
}

export default PhpComp