<footer class="container-fluid bg-info text-white p-3">
  <div class="container">
    this is footer
  </div>
</footer>