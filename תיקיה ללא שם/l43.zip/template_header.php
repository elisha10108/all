<header class="container-fluid bg-dark text-white p-3">
  <div class="container">
    this is header
  </div>
</header>