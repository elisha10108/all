<?php 
  define("START_LIVES",5);

  echo START_LIVES."<br>";

