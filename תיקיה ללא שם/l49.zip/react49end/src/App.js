import logo from './logo.svg';
import './App.css';
import AppMarket from './marketComps/appMarket';


function App() {
  return (
    <div className="App">
      <AppMarket />

     
    </div>
  );
}
// 10:50
export default App;
