import './App.css';
import AppLocal from './compsLocal/appLocal';
// import AppGallery from './hw_comps/appGallery';
// import AppColor from './hw_comps/appColors';
import AppShok from './hw_comps/appShok';
import AppVod from './vod_comps/appVod';

function App() {
  return (
    <div className="App">
      <AppLocal />
      {/* <AppVod /> */}
      {/* <AppShok /> */}
      {/* <AppColor /> */}
      {/* <hr/> */}
      {/* <AppGallery /> */}
    </div>
  );
}

export default App;
