<?php 

$time_now = time(); // כמה זמן עבר מ 1970
$time = time() + 60 * 60; 

echo $time_now;
echo "<br>";
echo $time;