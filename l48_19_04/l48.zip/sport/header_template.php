<header class="container-fluid bg-dark">
    <div class="container p-2">
      <nav>
        <a href="indexSport.php" class="text-white">All</a>
        <a href="football.php" class="text-white">Football</a>
        <a href="nba.php" class="text-white">NBA</a>
      </nav>
    </div>
  </header>