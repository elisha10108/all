$(() => {
  init();
})

const init = async() => {
  let myUrl = "http://localhost:3000/prods";
  adminTableManagerApi(myUrl);
}