const adminTableManagerApi = async(_url) => {
  let data = await doApi(_url);
  console.log(data);
  createTable(data)
}

const createTable = (_ar) => {
  $("#id_tbody").empty();
  _ar.map((item,i) => {
    let prodTr = new TrProd("#id_tbody",item,i)
    prodTr.render();
  })
}