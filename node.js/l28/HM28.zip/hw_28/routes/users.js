const express = require('express');
const {UserModel, validUser}=require("../userModel/userModel");
const router = express.Router();
const bcrypt = require('bcrypt');

/* GET users listing. */
router.get('/', async(req, res) => {
  let perPage=(req.query.perPage)? Number(req.query.perPage):5;
  let page=req.query.page;
  let sortQ=req.query.sort;
  let ifReverse=(req.query.reverse=="yes")? -1:1;
  try {
    let data=await UserModel.find({},{password:0})
    .sort({[sortQ]: ifReverse}) 
    .limit(perPage)
    .skip(page*perPage)
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(400).json({err:"there is a problem, try again later!"})
  }
});

router.post('/', async(req, res) => {
  let validate=validUser(req.body);
  if (validate.error){
    return res.status(400).json(validate.error.details)
  }
  try {
    let user= new UserModel(req.body);
    let salt=await bcrypt.genSalt(10);
    user.password=await bcrypt.hash(user.password, salt);
    await user.save();
    res.status(201).json(user)
  }
  catch(err){
    console.log(err);
    res.status(400).json({err:"there is a problem, try again later!"})
  }
})

module.exports = router;