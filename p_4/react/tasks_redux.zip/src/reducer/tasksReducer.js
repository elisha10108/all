// 3 מייצר רדיוסר עם סטייט התחלתי
let initState = {
  user:"koko",
  tasksRed_ar:[
    {name:"go to college",time:"2021-05-03",id:1},
    {name:"find work",time:"2021-06-30",id:2},
  ]
}

const taskReducer = (state = initState, action) => { 
  if(action.type == "addTask"){
    return {...state, tasksRed_ar:[...state.tasksRed_ar,action.task]}
  }
  return state;
}

export default taskReducer;