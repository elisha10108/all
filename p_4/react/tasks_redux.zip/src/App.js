import logo from './logo.svg';
import './App.css';
import AppTasks from './tasks_comps/appTasks';

function App() {
  return (
    <div className="App">
      <AppTasks />
    </div>
  );
}

export default App;
