import React, { useRef } from 'react';
import {useDispatch} from "react-redux"

function InputTasks(props) {
  let nameRef = useRef();
  let dateRef = useRef();

  let dispatch = useDispatch();

  const addTaskFromInputs = () => { 
    let newTask = {
      name:nameRef.current.value,
      time:dateRef.current.value,
      id:Date.now()
    }
    dispatch({type:"addTask",task:newTask});

  }

  return (
    <div className="container">
      <h1>Add new task:</h1>
      <div className="d-md-flex my-3 col-lg-6">
        <input placeholder="Enter task..." ref={nameRef} type="text" className="form-control me-2" />
        <input ref={dateRef} type="date" className="form-control" />
        <button onClick={addTaskFromInputs} className="btn btn-success w-50 mt-md-0 mt-2  ">Add task</button>
      </div>

    </div>
  )
}

export default InputTasks