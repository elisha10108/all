import React from 'react';
import {useSelector} from 'react-redux'

function TasksList(props){
  let tasks_ar = useSelector((myStore) => myStore.tasksRed_ar)

  return(
    <div className="container">
      <h2>Tasks you added:</h2>
      <div className="row">
        {tasks_ar.map(item => {
          return(
            <div className="col-lg-7 border p-2">
              {item.name} - {item.time}
            </div>
          )
        })}
      </div>
    </div> 
  )
}

export default TasksList