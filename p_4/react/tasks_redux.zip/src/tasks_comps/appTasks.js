import React from 'react';
import InputTasks from './inputTasks';
import TasksList from './tasksList';

// אימפורטים בשביל שהרידקס יעבוד 1
import {createStore} from 'redux';
import { Provider } from 'react-redux';
import taskReducer from '../reducer/tasksReducer';

// 2 מחבר את הסטור ואת הרידיוסר
const myStore = createStore(taskReducer);

// 4 שם את הקומפנינטה פרוביידר שעוטפת את כל הקומפנינטות ומקבלת את הסטור
function AppTasks(props){
  return(
    <Provider store={myStore}>
      <InputTasks />
      <TasksList />
    </Provider>
  )
}

export default AppTasks