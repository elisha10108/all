import logo from './logo.svg';
import './App.css';
import AppAdminTrivia from './compsAdmin_trivia/appAdminTrivia';

function App() {
  return (
    <div className="App">
      <AppAdminTrivia />
    </div>
  );
}

export default App;
