import logo from './logo.svg';
import './App.css';
import AppMarket from './marketComps/appMarket';
import AppRedux from './reduxTestComps/appRedux';
import ApiJsonLocal from './comps/apiJsonLocal';

function App() {
  return (
    <div className="App">
      <AppMarket />
      <hr/>
      <h2>Redux test</h2>
      <AppRedux />
      <ApiJsonLocal />
    </div>
  );
}
// 10:50
export default App;
