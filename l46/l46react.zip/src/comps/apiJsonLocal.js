import React, { useEffect } from 'react';

function ApiJsonLocal(props){
  useEffect(() => {
    doApi();
  },[])

  const doApi = async() => {
    try{
    let url = "/money.json";
    let resp = await fetch(url);
    let data = await resp.json();
    console.log(data);
    }
    catch(err){

    }
  }

  return(
    <div>ApiJsonLocal work</div> 
  )
}

export default ApiJsonLocal