import React from 'react';
import {useDispatch} from "react-redux"

function CounterControl(props){

  let dispatch = useDispatch();

  return(
    <div className="bg-warning p-2">
      <button onClick={() => {
        dispatch({type:"add1Counter"})
      }}>Add 1 counter</button>
      <button onClick={() => {
        dispatch({type:"addCustomCounter", number:3})
      }}>Add 3 counter</button>
      <button onClick={() => {
        dispatch({type:"addCustomCounter", number:10})
      }}>Add 10 counter</button>
    </div> 
  )
}

export default CounterControl