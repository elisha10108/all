import React from 'react';
import {useSelector, useDispatch} from "react-redux"

function CartTestList(props){
  let cart_ar = useSelector(myStore => myStore.cart_ar)
  let dispatch = useDispatch();

  return(
    <div className="col-lg-3 border p-3">
      <h3>In your Cart:</h3>
      {cart_ar.map(item => {
        return(
          <div key={item.id} className="border p-2 overflow-hidden">
            <button onClick={ () => {
              dispatch({type:"delItemFromCart",delId:item.id}) 
            }
            } className="float-end btn btn-danger">x</button>
            {item.name}
            </div>
        )
      })}
      
    </div> 
  )
}

export default CartTestList