import React from 'react';
import {useSelector} from "react-redux"

function CounterShow(props){
  let counter = useSelector((myStore) => myStore.counter);
  let username = useSelector((myStore) => myStore.user)

  return(
    <div>
      <h2>Counter: {counter}</h2>
      <h2>Username: {username}</h2>
    </div> 
  )
}

export default CounterShow

// 13:14