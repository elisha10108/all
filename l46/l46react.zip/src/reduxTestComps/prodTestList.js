import React, { useEffect, useState } from 'react';
import { doApiGet } from '../services/apiSer';
import {useDispatch} from "react-redux"

function ProdTestList(props){
  let dispatch = useDispatch()
  let [prod_ar,setProdAr] = useState([])


  useEffect(() => {
    doApi()
  },[])

  const doApi = async() => {
    let data = await doApiGet("http://fs1.co.il/bus/shop.php");
    console.log(data);
    setProdAr(data)
  }

  return(
    <div className="col-lg-9">
      <h1>List of prod</h1>
      <div className="row">
        {prod_ar.map(item => {
          return(
            <div key={item.id} 
            className="col-lg-4 border p-2 bg-dark text-white">
              <h2>{item.name} - {item.price} NIS</h2>
              <button onClick={() => {
                dispatch({type:"addToCart",itemProd:item})
              }} className="btn btn-light">add to cart</button>
            </div>
          )
        })}
      </div>
    </div> 
  )
}

export default ProdTestList