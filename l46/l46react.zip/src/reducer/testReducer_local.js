// הסטייט הגלולבי ההתחלתי שהאפליקציה מקבלת שהיא נטענת
const initState = {
  counter: 77,
  user:"moshe",
  cart_ar:[]
}

// single source of truth -> מקור אחד שמאפשר שינוי של הסטייט
const TestReducer = (state = initState , action) => {
  if(action.type == "add1Counter"){
    // ...state -> כדי שלמשל המאפיין יוזר לא ימחק מהסטייט
    // saveToLocal -> פונקציה לפני שהיא מחזיר לפרוביידר את הסטייט שומרת
    // אותו בלוקאל
    return saveToLocal({...state, counter:state.counter+1});
  }
  else if(action.type == "addCustomCounter"){
    return saveToLocal({...state, counter:state.counter+action.number})
  }
  else if(action.type == "addToCart"){
    // הוספת מוצר לעגלה 
    // הקומפנינטה CARTTESTLIST משתמשת במערך קארט איי אר
    return saveToLocal({...state, cart_ar:[...state.cart_ar,action.itemProd]})
  }
  else if(action.type == "delItemFromCart"){
    let temp_ar = state.cart_ar.filter(item => item.id != action.delId);
    return saveToLocal({...state,cart_ar:temp_ar});
  }
  // בודק אם יש מידע שמור בלוקאל  אפשר לשלוף 
  // ואם לא פשוט משתמש בסטייט הנוכחי
  state = (localStorage["reduxStore"]) ? JSON.parse(localStorage["reduxStore"]) : state;
  return state;
}
// 14:50
export default TestReducer;

// שומר את את הסטייט בלוקאל 
// במציאות עדיף שתיהיה בקובץ אחר
const saveToLocal = (state) => {
  localStorage.setItem("reduxStore",JSON.stringify(state));
  return state;
}